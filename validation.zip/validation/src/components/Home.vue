<template>
  <div>
    <h4>Welcome to School Activity Portal - Xpress</h4>
    <br />

    </div>
</template>

<script>
</script>

<style>
</style>