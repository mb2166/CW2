<template>
  <div>
    <!-- Error button and Collapsable card showing errors-->
    <b-button
      size="sm"
      class="mr-1"
      v-if="errors.length"
      v-b-toggle.collapse-1
      variant="primary"
    >! Errors</b-button>
    <b-collapse id="collapse-1" class="mt-2">
      <b-card>
        <span v-if="errors.length">
          <b>Please correct the following error(s):</b>
          <p v-for="(error, index) in errors" :key="index">{{ error }}</p>
        </span>
      </b-card>
    </b-collapse>

    <div id="register">
      <h4>Register</h4>eMail (username) :
      <input type="text" name="email" v-model="email" placeholder="email" />
      <br />
      <br />Password :
      <input type="password" name="email" v-model="pwd" placeholder="password" />
      <br />
      <br />Name :
      <input type="text" name="name" v-model="name" placeholder="name" />
      <br />
      <br />Surname :
      <input type="text" name="surname" v-model="surname" placeholder="surname" />
      <br />
      <br />Type :
      <select v-model="type">
        <option>Student</option>
        <option>Parent</option>
        <option>Provider</option>
      </select>
      <br />
      <br />

      <b-button size="sm" class="mr-1" type="button" v-on:click="addUser()">Register</b-button>&nbsp;
      <b-button size="sm" class="mr-1" type="button" to="Home">Cancel</b-button>&nbsp;
    </div>
  </div>
</template>

<script>
const API_URL_USERS = "http://localhost:4000/users";

export default {
  name: "Register", //this is the name of the component

  //data structure
  data() {
    return {
      Users: [], //array storing users
      email: "",
      pwd: "",
      name: "",
      surname: "",
      type: "",

      errors: []
    };
  },
  mounted() {
    //load users from mongoDB and populate the users array
    try {
      fetch(API_URL_USERS)
        .then(response => response.json())
        .then(result => {
          this.Users = result;
        });
    } catch (e) {
      this.errors.push("There was an error retrieving details from database.");
    }
  },
  methods: {
    saveUsers() {
      //delete all
      fetch(API_URL_USERS, {
        method: "DELETE",
        body: JSON.stringify(this.Users),
        headers: {
          "content-type": "application/json"
        }
      }).then(response => {
        //re-submit data to mongoDB
        if (response.status == 200) {
          fetch(API_URL_USERS, {
            method: "POST",
            body: JSON.stringify(this.Users),
            headers: {
              "content-type": "application/json"
            }
          }).then(response => {
            if (response.status == 200) {
                //redirect to home
                alert("Thanks for Registering.");
                this.$router.push("Home");
            } else {
              alert("Error on database.");
            }
          });
        } else {
          alert("Error on database.");
        }
      });
    }
  }
};
</script>
<style>
#register {
  width: 500px;
  border: 1px solid #cccccc;
  background-color: #ffffff;
  margin: auto;
  margin-top: 20px;
  padding: 20px;
}
</style>