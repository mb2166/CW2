const db = require('./connection');
 
const activities = db.get('activities');
 
function getAll() {
    return activities.find();
}
 
function create(data) {  
    return activities.insert(data);    
}

function deleteAll() {  
    return activities.remove(); 
}
 
module.exports = {
    create,
    getAll,
    deleteAll
};