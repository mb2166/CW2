<template>
  <div>
    <h4>Class & Activities Administration</h4>

    <!-- Class Activities Admin page-->

    <!-- Show / Hide add button-->
    <div v-show="!formmode" v-on:click="formmode = !formmode" class="control">
      <b-button size="sm" class="mr-1">Add New Class / Activity</b-button>
    </div>

    <!-- Form-->
    <div v-if="formmode" id="hide">
      <!-- Error button and Collapsable card showing errors-->
      <b-button
        size="sm"
        class="mr-1"
        v-if="errors.length"
        v-b-toggle.collapse-1
        variant="primary"
      >! Errors</b-button>

      <b-collapse id="collapse-1" class="mt-2">
        <b-card>
          <span v-if="errors.length">
            <b>Please correct the following error(s):</b>
            <p v-for="(error, index) in errors" :key="index">{{ error }}</p>
          </span>
        </b-card>
      </b-collapse>

      <!--Div showing the input fields -->
      <div class="ClassActivity">
        Topic :
        <input
          v-if="!editmode"
          type="text"
          name="topic"
          id="topic"
          v-model="topic"
          placeholder="topic"
        />
        <input
          v-if="editmode"
          type="text"
          name="topic"
          id="topic"
          v-model="topic"
          placeholder="topic"
          disabled
        />
        <br />
        <br />Price EUR :
        <input type="number" id="price" name="price" v-model="price" placeholder="price" />
        <br />
        <br />Location :
        <input
          type="text"
          id="location"
          name="location"
          v-model="location"
          placeholder="location"
        />
        <br />
        <br />Time :
        <input type="text" id="time" name="time" v-model="time" placeholder="time frequency" />
        <br />
        <br />Length (hrs):
        <input
          type="number"
          id="length"
          name="length"
          v-model="length"
          placeholder="length"
        />
        <br />
        <br />Provider (email):
        <input
          type="text"
          name="provider"
          v-model="provider"
          placeholder="Provider email"
        />
        <br />
        <br />Type :
        <select id="type" name="type" v-model="type">
          <option>Class</option>
          <option>Activity</option>
        </select>
        <br />
        <br />

        <!-- buttons save, cancel and edit toggled depending on the mode set -->
        <b-button size="sm" class="mr-1" v-show="formmode" @click="Cancel">Cancel</b-button>&nbsp;
        <b-button size="sm" class="mr-1" v-show="!editmode" @click="addClassActivity">Save</b-button>
        <b-button size="sm" class="mr-1" v-show="editmode" @click="updateClassActivity">Update</b-button>
      </div>
    </div>

    <br />

    <!-- display data in grid-->

    <div v-show="!formmode">

          <b-button
            size="sm"
            @click="topicratings(row.item, $event.target)"
            class="mr-1"
          >Rating Details</b-button>
          <b-button size="sm" class="mr-1" @click="getTopictoRemove(row.item.topic)">Remove</b-button>&nbsp;
          <b-button size="sm" class="mr-1" @click="getTopictoEdit(row.item.topic)">Edit</b-button>
        </template>
      </b-table>

      <!--Modal window for rating -->
      <b-modal :id="infoModal.id" :title="infoModal.title" ok-only @hide="resetInfoModal">
        <pre>{{ infoModal.content }}</pre>
      </b-modal>

      <div align="right">
        Sorting By:
        <b>{{ sortBy }}</b>, Sort Direction:
        <b>{{ sortDesc ? 'Descending' : 'Ascending' }}</b>
      </div>
    </div>

    <!--used for debug 
    <ul v-for="(value, index) in ClassActivityRatings" v-bind:key="index">
      <li>{{value}} ({{index}})</li>
    </ul>

    <ul v-for="(value, index) in ClassActivity" v-bind:key="index">
      <li>{{value}} ({{index}})</li>
    </ul>
    -->
  </div>
</template>

<script>
const API_URL_ACTIVITIES = "http://localhost:4000/activities";
const API_URL_ACTIVITIESRATINGS = "http://localhost:4000/activitiesratings";

export default {
  name: "ClassActivity", //this is the name of the component

  data() {
    return {
      //local storage attributes and array
      ClassActivity: [],
      topic: "",
      price: "",
      location: "",
      time: "",
      length: "",
      provider: "",
      type: "",

      ClassActivityRatings: [],
      topic_id: "", //topic
      rating: "", // rating
      submission_email: "", //user who submitted rating

  mounted() {
    //load ClassActivity from mongoDB and populate the users array
    
    try {
      fetch(API_URL_ACTIVITIES)
        .then(response => response.json())
        .then(result => {
          this.ClassActivity = result;
        });
    } catch (e) {
      this.errors.push("There was an error retrieving details from database.");
    }

    //load ClassActivityRatings from mongoDB and populate the users array
    try {
      fetch(API_URL_ACTIVITIESRATINGS)
        .then(response => response.json())
        .then(result => {
          this.ClassActivityRatings = result;
        });
    } catch (e) {
      this.errors.push("There was an error retrieving details from database.");
    }
  }
};
</script>

<style>
.ClassActivity {
  width: 500px;
  border: 1px solid #cccccc;
  background-color: #ffffff;
  margin: auto;
  margin-top: 20px;
  padding: 20px;
}
</style>