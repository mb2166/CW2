<template>
  <div>
    <h1>About</h1>
    <p>This is an App using VUE.JS</p>
  </div>
</template>

<script>
export default {
  name: 'About' //this is the name of the component
}
</script>
<style>
</style>