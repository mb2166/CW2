const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const morgan = require('morgan');
 
const users = require('./dbmodules/users');
const activities = require('./dbmodules/activities');
const activitiesratings = require('./dbmodules/activitiesratings');
 
const app = express();
 
app.use(morgan('tiny'));
app.use(cors());
app.use(bodyParser.json());
 
app.get('/', (req, res) => {
    res.json({
        message: 'MongoApp Node Server running!'
    });
});
 
//users APIs
app.get('/users', (req, res) => {
    users.getAll().then((users) => {
        res.json(users);
    });
});
 
app.delete('/users', (req, res) => {
    users.deleteAll().then((users) => {
        res.json(users);
    }).catch((error) => {
        res.status(500);
        res.json(error);
    });
});

app.post('/users', (req, res) => {
    users.create(req.body).then((users) => {
        res.json(users);
    }).catch((error) => {
        res.status(500);
        res.json(error);
    });
});

//activities/ class APIs
app.get('/activities', (req, res) => {
    activities.getAll().then((activities) => {
        res.json(activities);
    });
});
 
app.delete('/activities', (req, res) => {
    activities.deleteAll().then((activities) => {
        res.json(activities);
    }).catch((error) => {
        res.status(500);
        res.json(error);
    });
});

app.post('/activities', (req, res) => {
    activities.create(req.body).then((activities) => {
        res.json(activities);
    }).catch((error) => {
        res.status(500);
        res.json(error);
    });
});

//activities/ class ratings APIs
app.get('/activitiesratings', (req, res) => {
    activitiesratings.getAll().then((activitiesratings) => {
        res.json(activitiesratings);
    });
});
 
app.delete('/activitiesratings', (req, res) => {
    activitiesratings.deleteAll().then((activitiesratings) => {
        res.json(activitiesratings);
    }).catch((error) => {
        res.status(500);
        res.json(error);
    });
});

app.post('/activitiesratings', (req, res) => {
    activitiesratings.create(req.body).then((activitiesratings) => {
        res.json(activitiesratings);
    }).catch((error) => {
        res.status(500);
        res.json(error);
    });
});


 
const port = process.env.PORT || 4000;
app.listen(port, () => {
    console.log(`listening on ${port}`);
});